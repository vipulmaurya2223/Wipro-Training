import React, { useState } from "react";
import UserList from "./components/UserList";
import UserForm from "./components/UserForm";

const App = () => {
    const [users, setUsers] = useState([]);

    const addUser = (newUser) => {
        setUsers([...users, newUser]);
    };

    return (
        <div>
            <h1>User Management System</h1>
            <UserForm onUserAdded={addUser} />
            <UserList />
        </div>
    );
};

export default App;
