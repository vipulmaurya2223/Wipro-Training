require("dotenv").config();
const express = require("express");
const cors = require("cors");
const http = require("http");
const socketIo = require("socket.io");
const axios = require("axios");

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "http://localhost:5173", // React frontend URL
        methods: ["GET", "POST"]
    }
});

app.use(cors());
app.use(express.json());

// Sample Stock Data
let stockPrices = {
    AAPL: 150.25,
    TSLA: 700.10,
    MSFT: 280.75,
};

// API Route for fetching stock data
app.get("/stock/:symbol", async (req, res) => {
    const symbol = req.params.symbol.toUpperCase();
    
    if (!stockPrices[symbol]) {
        return res.status(404).json({ message: "Stock not found" });
    }

    res.json({ symbol, price: stockPrices[symbol] });
});

// Root Route
app.get("/", (req, res) => {
    res.send("Stock Market API is Running...");
});

// WebSocket Connection
io.on("connection", (socket) => {
    console.log("New client connected");

    // Send stock updates every 5 seconds
    setInterval(() => {
        for (let stock in stockPrices) {
            stockPrices[stock] += (Math.random() * 10 - 5).toFixed(2); // Simulate price changes
        }
        socket.emit("stockUpdate", stockPrices);
    }, 5000);

    socket.on("disconnect", () => {
        console.log("Client disconnected");
    });
});

// Start Server
const PORT = process.env.PORT || 5001;
server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
