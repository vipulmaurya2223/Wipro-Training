import React, { Component } from "react";
import io from "socket.io-client";
import "bootstrap/dist/css/bootstrap.min.css";

class StockDashboard extends Component {
    constructor(props) {
        super(props);
        this.state = {
            stockSymbol: "",
            stockData: null,
            previousStocks: [],
            socket: io("http://localhost:5000"),
        };
    }

    componentDidMount() {
        this.state.socket.on("stockData", (data) => {
            this.setState({ stockData: data });
        });
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevState.stockSymbol !== this.state.stockSymbol) {
            this.state.socket.emit("getStock", this.state.stockSymbol);
        }
    }

    handleInputChange = (e) => {
        this.setState({ stockSymbol: e.target.value });
    };

    handleSearch = () => {
        if (this.state.stockSymbol.trim() !== "") {
            this.setState((prevState) => ({
                previousStocks: [...prevState.previousStocks, prevState.stockSymbol],
            }));
            this.state.socket.emit("getStock", this.state.stockSymbol);
        }
    };

    render() {
        return (
            <div className="container mt-4">
                <h2 className="text-center">📈 Real-Time Stock Tracker</h2>
                <div className="input-group mb-3">
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Enter Stock Symbol (e.g., AAPL)"
                        value={this.state.stockSymbol}
                        onChange={this.handleInputChange}
                    />
                    <button className="btn btn-primary" onClick={this.handleSearch}>
                        Search
                    </button>
                </div>

                {this.state.stockData && (
                    <div className="card p-3">
                        <h4>{this.state.stockData.name} ({this.state.stockData.symbol})</h4>
                        <p>Price: ${this.state.stockData.price}</p>
                        <p>Change: {this.state.stockData.change}%</p>
                    </div>
                )}

                <h5 className="mt-4">Previous Searches:</h5>
                <ul className="list-group">
                    {this.state.previousStocks.map((stock, index) => (
                        <li key={index} className="list-group-item">
                            {stock}
                        </li>
                    ))}
                </ul>
            </div>
        );
    }
}

export default StockDashboard;
